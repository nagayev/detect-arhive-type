package main

import (
	"fmt"
	"os"
)
func getType(path string)string{
	file, err := os.Open(path)
	buffer := make([]byte, 512)
	_, err = file.Read(buffer)
	if err != nil {
		panic(err)
	}
	fileType:="tar"
	return fileType
}
func main(){
	fmt.Println(getType("nano.tar.gz"))
}