package main

import (
	"fmt"
	"os"
	"bufio"
	"bytes"
)
const (
	//UNKNOWN file, default value
	UNKNOWN=0
	//TARGZ is .tar.gz file
	TARGZ=1
	//ZIP is .zip file
	ZIP=2
)
func getType(path string) (int,error) {
	file, err := os.Open(path)
	if err!=nil{
		fmt.Println(err)
		return UNKNOWN,err
	}
	fileType:=UNKNOWN
	reader := bufio.NewReader(file)
	buffer:=make([]byte,8)
	targzSignature:=[]byte{31,139}
	zipSignature:=[]byte{0x50,0x4B,0x03,0x04}
	//NOTE: elements' order is special (same as constants) 
	formats:=[][]byte{targzSignature,zipSignature}
	reader.Read(buffer)
	fmt.Println(buffer)
	for i:=0;i<len(formats);i++{
		format:=formats[i]
		if bytes.HasPrefix(buffer,format){
			fileType=i+1
		}
	}
	return fileType,err
}
func main(){
	testType,err:=getType("nano.tar.gz")
	if err!=nil{
		fmt.Println(err)
	}
	fmt.Println(testType)
}